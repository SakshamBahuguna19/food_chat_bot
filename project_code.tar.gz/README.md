# Steps

* create a firebase project and get service accound credentials
* run `node helper_functions/configuration_create.js`
* run `node helper_functions/item_create.js`
