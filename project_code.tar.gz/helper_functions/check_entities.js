const fs = require('fs');

const DIALOGFLOW_API = require('./dialogflow_api');

const entities_json = require('./data_files/rasoi_synonyms.json');

const sleep = (milliseconds) => {
    const date = Date.now();
    let currentDate = null;
    do {
        currentDate = Date.now();
    } while (currentDate - date < milliseconds);
};

const callThisFunction = async () => {

    let responses = [];

    for (let index = 0; index < entities_json.length; index++) {
        let element = entities_json[index];
        let menu_item = element.Key;

        let res = await DIALOGFLOW_API.detectIntent('en', menu_item, 'abcdef123456');

        if (res.status == 1) {
            responses.push(
                {
                    menu_item: menu_item,
                    response: res.text
                }
            );
        } else {
            responses.push(
                {
                    menu_item: menu_item,
                    response: 'Error detecting the intent.'
                }
            );
        }

        sleep(1000);
    }

    fs.writeFileSync(
        'functions/helper_functions/data_files/check_entities.json',
        JSON.stringify(responses, 2, ' ')
    );
    console.log('Finished.');
};

callThisFunction();