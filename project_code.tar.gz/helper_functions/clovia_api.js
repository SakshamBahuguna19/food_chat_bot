const axios = require('axios');

const MID = 'YBG4N9515MVS1';
const API_KEY = 'baa1c982-9613-9938-5c1e-97811c022109';

const BASE_URL = 'https://api.clover.com/v3/merchants';

const create_bulk_order = async (cart, mobile, name) => {

    let order_config = {
        method: 'post',
        url: `${BASE_URL}/${MID}/orders`,
        headers: {
            'authorization': `Bearer ${API_KEY}`
        }
    };

    let order_response = await axios(order_config);

    let order_id = order_response.data.id;

    let items = [];

    cart.forEach(ci => {
        for (let index = 0; index < ci.item_quantity; index++) {
            items.push(
                {
                    item: {},
                    name: ci.item_name,
                    price: ci.item_price * 100,
                    taxRates: [
                        {
                            id: '8YY7KPJQD8G4Y',
                            rate: 860000,
                            name: 'Sales Tax'
                        }
                    ]
                }
            );
        }
    })

    let data = JSON.stringify(
        {
            "items": items,
            "note": `OneZing - ${name} - ${mobile}.`
        }
    );

    let bulk_order_config = {
        method: 'post',
        url: `${BASE_URL}/${MID}/orders/${order_id}/bulk_line_items`,
        headers: {
            'authorization': `Bearer ${API_KEY}`,
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(bulk_order_config);

    return order_id;
};

const print_order = (order_id) => {

    let data = JSON.stringify({
        'orderRef': {
            'id': order_id
        }
    });

    let config = {
        method: 'post',
        url: `${BASE_URL}/${MID}/print_event`,
        headers: {
            'authorization': `Bearer ${API_KEY}`,
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        data: data
    };

    try {
        axios(config);
    } catch (error) {
        console.log(`Error at print_order --> ${error}`);
    }
};

module.exports = {
    create_bulk_order,
    print_order
};