// Import the packages we need
const dialogflow = require('@google-cloud/dialogflow');

// Your credentials
const CREDENTIALS = JSON.parse(JSON.stringify({
    "type": "service_account",
    "project_id": "hyderabadrasoi-kchq",
    "private_key_id": "9e2c32067bac4640333e6fdebc3a98c110d2bdf4",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQC4G2MaT4aoqxSi\nVe6kxqiszNfFlmNqXs8S16qiCw3Q39kAxkkL/oT/sa1p4PaHFltcI6My78B4JQrK\new1xPAnEcvAB6XpYXMay9Lgx/vp7fJWHyGPzxdOPvE8UhFNUF9TKqqzJa/YBId/2\nAjE/Ca1BE0BAOPPn7zKErYYkdiTGzOdt1qIfnoHWXhy40o4lhGxdMdyRCVoHLDp/\nI+kbgDAgHqsxPQxopDmd3ehay1aR9dMQLZc6AND2MWa5pPe30WLEKtgVQlbdo/Ng\nl/f+yVskJ0Ub739NCMHOXfSCi6tKXIbdFkBdqPeGGj3ZnPR/gSuuy7tOlh0p5oA6\nf3BM+NrFAgMBAAECggEAP4gX5VLvJZJP/wsHXK4/M85GYWVZrjHEZHyu4ddNr7gn\nYsiKGYz9qVzPeluKxygUY9Hade/dK7igpinbhClTN4rwPsCqmwZ8/PFNBNe36Vgf\nI6mnsE4iiRXS9kIJnVnR8RP/p0xNqqtdZT/xbY7xziSOBfuBU5asCLP2t+tbGoyy\nNGwTpQf6TEndRwVmIkUjVdK8qQ7PhWOnnfwsvstakbKfNIw7en1DVYyTYXpfVRdY\nUtSm0aH7HeHObCvHnk3TmbZrjtP8GdUD69OvrKgkTHZseZr28a5ZUmlUigd8R2YX\nuYNb7A7K3xvGwYEkjwJAP8bbChvCVLUH4jibbA9/ywKBgQDZs9IRy3AAtlZhVzvz\nNZe4oWE1QJYh2uHshF4KQg7yZ1nQ8w2ihoTnPkW7Y5v1ZYJMiZH8tfMEgu5DA8IG\nGb+lDLRQKTyH5TtYDDq7gnCWfnzjNH9k8pd53LfVNJebA89K6a8mNM7FX4Gu+hKa\nKJjU2bJ0AdpF74dVQJXKf9ZEIwKBgQDYfpp1RgrAzntBDQLqbXwnss3Eae5Uzck3\nC1paii5PNzl4Bp+Rj9e0R4S9lcbFYDJ3dodM0HyQf0X3SWWAagWnGuxNqwqo5hHG\nv3g+t6zbWPjm69G9faBalaEtF+yfgTNK1zLm+oehiwif1pUCeAUPV7zlJbSv+Mac\nlU8pLO2/9wKBgFJym7hJh519cLFkzDuLrG4sEBiO4UzpDG76onLYGbkMEyPjKOLI\nd0TsfJQ/YS1KyFIcN8GxVtv6iimvHqgY0E+9w/wn4djFo/fwib3B5MnaFYoms6iT\nh3KLeMOyK0h15OfGIKMjlLuDNCYEZ08i2N6jo8XzfarG0EYlM5WBXLBpAoGAQpA6\ngVA1wi46KzgK63UaNUJ+jaNcSeqzsR7meuv9bRG3s7WlniWx1pYetAO3B7yaB60D\n0JRRmEPpiSyh7qeqcUSP3xl1v5RtZsQ7/lyO4yop7SYYaMCVawSSd8DhWfFpids8\npVPmG78ZubtKOWYZeCwrwfCj62778ezeV/SebOUCgYAzulQkLCgsvws7dDjSjJsP\ngQ5Gs/kune+tRGIaX4Pc/gbOlfibwggSv6KQgpslvMPtJ4bIKEUPX8Gn2PrXqBzB\nWCqFaYsfGGjq/w9gUVMbZHpsoz48dTeVgQ8dlfPW93NUqMm6y/aAPj2vOsfTwx5q\nKBsXJd01hivWQUrC9wM8sw==\n-----END PRIVATE KEY-----\n",
    "client_email": "hyderabadrasoi-kchq@appspot.gserviceaccount.com",
    "client_id": "106018606869144930261",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/hyderabadrasoi-kchq%40appspot.gserviceaccount.com"
}));

// Your google dialogflow project-id
const PROJECID = CREDENTIALS.project_id;

// Configuration for the client
const CONFIGURATION = {
    credentials: {
        private_key: CREDENTIALS['private_key'],
        client_email: CREDENTIALS['client_email']
    }
}

// Create a new session
const sessionClient = new dialogflow.SessionsClient(CONFIGURATION);

// Detect intent method
const detectIntent = async (languageCode, queryText, sessionId) => {

    let sessionPath = sessionClient.projectAgentSessionPath(PROJECID, sessionId);

    // The text query request.
    let request = {
        session: sessionPath,
        queryInput: {
            text: {
                text: queryText,
                languageCode: languageCode,
            },
        },
    };

    try {
        // Send request and log result
        const responses = await sessionClient.detectIntent(request);
        const result = responses[0].queryResult;
        return {
            status: 1,
            text: result.fulfillmentText
        };
    } catch (error) {
        console.log(`Error at dialogflow-ai.js detectIntent --> ${error}`);
        return {
            status: 0
        };
    }
};

module.exports = {
    detectIntent
};