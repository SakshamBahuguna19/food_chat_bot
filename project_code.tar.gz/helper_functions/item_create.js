const { Firestore } = require('@google-cloud/firestore');

const CREDENTIALS = JSON.parse(JSON.stringify({
    "type": "service_account",
    "project_id": "youtubedemo-rwcl",
    "private_key_id": "f07aa1b756b1a690f9d13794a3c0922d9df0eed9",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDX1uJbfMnALbNU\nSDEc5zRbMPCLogf3luG24TQczzZyy6XUraymqCp2/xAm6Ozfl2g387mbKR1Oxtq4\nrTfN/ANzhe48kiJY+jghdzecITBOi7nBNKHuzLp9XwUYlC7CahD7OGxewjDN0xtv\ng1jJNydnc/Z6d7nwC8oC6DvR2FwDbX93WIX2Zo1ktWW1orI9jRiEoLrOpgvMxi3W\n4efFwgpkubBi0lqTSoSevJmdu7dmEh6vUw7rvl2Z3SXbuLeOr7HS0UdgGlHHkH7A\nsab+Pq4mii9+bxE3jpUFFUziaXNY7GEVkegng7fEO6i4ZyArhnL85d/kGs99EEsm\n8plOgzzBAgMBAAECggEACSOhLAyJomiM+lmgMsAbeG0HEnKG8dXistKwWTPw80Vq\nPSopcFkYizdboLomJYWMtSnNxyMjiY1j/4PeJAuyvbaDEu+BItFdhRU+No81M245\nLFQlMy5aCyr11UeY/0Rseaa2+AAy/tQcikk+fi6mrXu8iQz+w4pMQHlC5yzJIJ/z\nZ1/wPi4Idhy6xMmym65cMV0pO5odHfAoXYJdVh238C7YUgyOE/3Sf8uuaBaQA/sU\nl5kLvQk1D3BQFuKnq4FFsHNLXP2Ig27adQvy9lYueA1FwHPeStI432GHIbmb+ja+\nYkFM8E2TRE+ygXOPRrumH+Pilsv6bqpfrMccH4dwQQKBgQDwZfKcXLj6lzj57tmB\nGWOq04w58BuuoppBCE8/EurEi63l6pqlL98rRyXeJFdWtBWKq06C2llc4MbOF3Dp\nCnUiyFgHcvrCdd+V3LKr4g38zRvS7oIms6O2PrB6bpoElI6N1OhDKgKOqO6C1Wnz\nhZiRXFypC9Hfx4vo8+nQ1NrMqQKBgQDl2Oh8FgIzrV1XzWKSJ9rXWJPZRND2e7J+\nOin3h6lrIHgkDmpvgMPGDPCo3EoThbJawbjG6taOdIJp7BCWsGxDyeYIRZpNFckX\nBqU3+GIQzxOafSQbQM14UcADI2Pk3cL4hcnqN0yd0PMI0EF3WHG5FCCOVE/VitJ9\nZliuxSkmWQKBgQDFdJdwA2EUw31THPKebYJF3/j/5c53BKv62p5sylb3FVvCy442\nPDnsTEY4TlVGrCg9fDPCmyJnfWEOCob9g09vQGu9wp1heHwrldlUARtIGBjQioNw\n0oCXwqomBg6P0I2+xa/46tqq3ur5n92k3ojQbLLXTxQV4Mt0jlPw6cTF8QKBgAJ0\neqc4pPVgWKrjarYc7t11+L5NWd4IHDP08xXNwSV/x0i7Tq+6NF0dLkTfdXsX5nvJ\nreuR/pCu9eWju9mgMMfYlDhqZeeE4Az66TDb2lBLpe30gDo6SveKB/8AlcSQCdEV\nvL5fsNXOsYnaj5hyvWQ4rtBWXjPts6nbOf9D49ihAoGBAK1WymgopQsWqeIEuuJv\nNQMFPX3cHLPY0XWSnLDzH3EZT6pIY3RKIMibvkWBAlw2SkmA2SfJtUuVHxpAXP3F\ncZF3kmQKnLIxG/nc0xOlnELOyU1IRkNhBOlhEZ2PqT7jETF1N8wCDb4rjE77i8Ur\nWtMoBJ/GKiZybD5X60yn1Sz/\n-----END PRIVATE KEY-----\n",
    "client_email": "youtubedemo-rwcl@appspot.gserviceaccount.com",
    "client_id": "115344127562630496839",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/youtubedemo-rwcl%40appspot.gserviceaccount.com",
    "universe_domain": "googleapis.com"
}));

const firestore = new Firestore({
    projectId: CREDENTIALS.project_id,
    credentials: {
        client_email: CREDENTIALS.client_email,
        private_key: CREDENTIALS.private_key
    }
});

const menu_items = firestore.collection('menu_items');

const createMenuItem = async (record) => {

    try {
        await menu_items.add(record);
        console.log('Records created.');
    } catch (error) {
        console.log(`Error at createRecord --> ${error}`);
        console.log('Record -->');
        console.log(record);
    }
};

let database = require('./data_files/inventory Rasoi.json');

for (let index = 0; index < database.length; index++) {
    let element = database[index];
    element['isActive'] = true;
    createMenuItem(element);
}