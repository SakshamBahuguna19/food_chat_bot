const nodemailer = require('nodemailer');

const sendMail = async (message, receiverEmail, subject, html) => {

    let transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        service: 'gmail',
        secure: false,
        auth: {
            user: 'onezingai@gmail.com',
            pass: 'fzbbyiphxvkukkvq',
        },
    });

    let info = await transporter.sendMail({
        from: process.env.EMAIL,
        to: receiverEmail,
        subject: subject,
        text: message,
        // html: html
    });

    console.log(`Email sent: ${info.messageId}`);
};

module.exports = {
    sendMail
};