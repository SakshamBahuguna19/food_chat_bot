const createOrderHTML = (order) => {

  let cart = order.cart;

  let items = '';

  let total = 0.0;

  cart.forEach(item => {
    let item_price = item.item_price * item.item_quantity;
    items += `<tr>
        <td>${item.item_name}</td>
        <td style="text-align: right">${item.item_price}$</td>
        <td style="text-align: right">${item.item_quantity}</td>
        <td style="text-align: right">${item_price.toFixed(2)}$</td>
      </tr>`
    total += item_price;
  });

  let html = `<body>
<h1>Order details</h1>
<div style="display: flex; justify-content: space-between">
  <div>
    Name - ${order.name.toUpperCase()}<br />
    Mobile - ${order.phone}
  </div>
</div>
    <div style="margin-top: 7em">
      <table style="width: 100%">
        <tbody>
          <tr style="font-weight: bold">
            <td style="width: 40%">Item</td>
            <td style="width: 20%; text-align: right">Price per unit</td>
            <td style="width: 10%; text-align: right">Qty</td>
            <td style="width: 20%; text-align: right">Price</td>
          </tr>
          ${items}
          <tr style="height: 5em; vertical-align: bottom">
            <td></td>
            <td></td>
            <td style="font-weight: bold; text-align: right">Total</td>
            <td style="text-align: right">${total.toFixed(2)}$</td>
          </tr>
        </tbody>
      </table>
    </div>
</body>`;

  return html;
};

module.exports = {
  createOrderHTML
};