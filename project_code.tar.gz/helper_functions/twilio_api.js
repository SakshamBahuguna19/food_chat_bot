// const ACCOUNT_SID = 'AC9faab11939356e276ca3ff4cbb65961d';
// const AUTH_TOKEN = '32956cd219827d96871750a7f398aa02';

// const client = require('twilio')(ACCOUNT_SID, AUTH_TOKEN, {
//     lazyLoading: true
// });

// const sendWhatsAppMessage = async (message, senderId) => {

//     let id = `${senderId}`;

//     try {
//         // WhatsApp number
//         let response = await client.messages.create({
//             from: 'whatsapp:+14155238886',
//             body: message,
//             to: id,
//         });
//         console.log(`WhatsApp Message sent --> ${response.sid}`);
//     } catch (error) {
//         console.log(`Error at sendWhatsAppMessage --> ${error}`);
//     }
// };

// const sendSMS = async (to, message) => {

//     try {
//         // SMS number
//         let response = await client.messages.create({
//             body: message,
//             from: '+18106313038',
//             to: to
//         });
//         console.log(`SMS Message sent --> ${response.sid}`);
//     } catch (error) {
//         console.log(`Error at sendSMS --> ${error}`);
//     }
// };

// module.exports = {
//     sendWhatsAppMessage,
//     sendSMS
// };