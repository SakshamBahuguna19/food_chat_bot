const express = require('express');

const webApp = express();

webApp.use(express.urlencoded({ extended: true }));
webApp.use(express.json());
webApp.use((req, res, next) => {
    console.log(`Path ${req.path} with Method ${req.method}`);
    next();
});

const home_route = require('./routes/home_route');
const dialogflow_route = require('./routes/dialogflow_route');
// const twilio_route = require('./routes/twilio_route');
const sms_route = require('./routes/sms_route');
// const clovia_route = require('./routes/clovia_route');

webApp.use(home_route.router);
webApp.use(dialogflow_route.router);
// webApp.use(twilio_route.router);
webApp.use(sms_route.router);
// webApp.use(clovia_route.router);

const PORT = process.env.PORT || 5000;

webApp.listen(PORT, () => {
    console.log(`Server is up and running at ${PORT}`);
});

