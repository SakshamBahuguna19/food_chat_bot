const axios = require('axios');

const create_bulk_order = async (cart) => {

    let order_config = {
        method: 'post',
        url: 'https://apisandbox.dev.clover.com/v3/merchants/V5C7XRTPNNXF1/orders',
        headers: {
            'authorization': 'Bearer b52a6461-0ee9-a15c-6b5f-2f46c70e416f'
        }
    };

    let order_response = await axios(order_config);

    let order_id = order_response.data.id;

    let items = [];

    cart.forEach(ci => {
        for (let index = 0; index < ci.item_quantity; index++) {
            items.push(
                {
                    item: {},
                    name: ci.item_name,
                    price: ci.item_price * 100,
                    // taxRates: [
                    //     {
                    //         id: '{taxRate UUID}',
                    //         rate: 200000,
                    //         name: 'Sales Tax'
                    //     }
                    // ]
                }
            );
        }
    })

    let data = JSON.stringify({
        "items": items
    });

    let bulk_order_config = {
        method: 'post',
        url: `https://apisandbox.dev.clover.com/v3/merchants/V5C7XRTPNNXF1/orders/${order_id}/bulk_line_items`,
        headers: {
            'authorization': 'Bearer b52a6461-0ee9-a15c-6b5f-2f46c70e416f',
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(bulk_order_config);
};

const print_order = (order_id) => {

    let data = JSON.stringify({
        'orderRef': {
            'id': order_id
        }
    });

    let config = {
        method: 'post',
        url: 'https://apisandbox.dev.clover.com/v3/merchants/V5C7XRTPNNXF1/print_event',
        headers: {
            'authorization': 'Bearer b52a6461-0ee9-a15c-6b5f-2f46c70e416f',
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        data: data
    };

    try {
        axios(config);
    } catch (error) {
        console.log(`Error at print_order --> ${error}`);
    }
};

module.exports = {
    create_bulk_order,
    print_order
}

