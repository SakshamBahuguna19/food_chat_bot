const express = require('express');
const router = express.Router();

const CLOVIA_API = require('../helper_functions/clovia_api');

router.post('/create_order', async (req, res) => {

    let cart = req.body.cart;
    let mobile = req.body.mobile;
    let name = req.body.name;

    let order_id = await CLOVIA_API.create_bulk_order(cart, mobile, name);
    console.log('Clover order created.');
    console.log(order_id);
    // CLOVIA_API.print_order(order_id);

    res.sendStatus(200);
});

module.exports = {
    router
};