const express = require('express');
const router = express.Router();
const axios = require('axios');

const FIREBASE_API = require('../helper_functions/firebase_api');
// const MAIL_API = require('../helper_functions/mail_api');
// const TWILIO_API = require('../helper_functions/twilio_api');
// const ORDER_API = require('../helper_functions/order_api');

const getErrorMessage = () => {
    return {
        fulfillmentText: 'We are facing an issue, please try after sometime.'
    };
};

const checkRestaurantTimings = async () => {
    let response = await FIREBASE_API.getOpenTime("MST");
    console.log('checkRestaurantTimings + getOpenTime');
    console.log(response);

    if (response.status == 1) {
        return {
            status: 1,
            fulfillmentText: 'Hello, Welcome, I can help you with ordering food, working hours of the restaurant, location, and contact information. How can I help you today?'
        };
    } else {
        return {
            status: 0,
            fulfillmentText: 'Hello, Welcome, I can help you with ordering food, but these are outside of operating hours. Please check the timings and order again'
        };
    }
};

const checkTimingsForOrder = async () => {
    let responseData = await checkRestaurantTimings();
    return {
        fulfillmentText: responseData.fulfillmentText
    };
};

const handleUserAsksForMenuItem = async (req) => {

    let menu_item = req.body.queryResult.parameters.menu_item;

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let response = await FIREBASE_API.getMenuItem(menu_item);
    console.log('handleUserAsksForMenuItem + getMenuItem');
    console.log(response);

    if (response.status == 0) {
        return getErrorMessage();
    }

    if (response.status == 2) {
        return {
            fulfillmentText: `Sorry, we don't serve ${menu_item} at this moment. You can search for other food items.`
        }
    }

    if (response.status == 1 && !response.data[0].isActive) {
        return {
            fulfillmentText: `Sorry, we have stopped receiving new orders for ${menu_item}. Please try again afyer sometimes.`
        };
    }

    if (response.status == 1) {
        let session = req.body.session;
        let await_add_to_cart = `${session}/contexts/await_add_to_cart`;
        let session_cart = `${session}/contexts/session_cart`;
        return {
            fulfillmentText: `We have ${menu_item}, it costs ${response.data[0].Price}$. Do you want to add ${menu_item} to your order?`,
            outputContexts: [
                {
                    name: await_add_to_cart,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        item: response.data[0],
                        cart: cart
                    }
                }
            ]
        };
    }
};

const handleUserProvidesMenuItem = async (req) => {

    let menu_item = req.body.queryResult.parameters.menu_item;

    let response = await FIREBASE_API.getMenuItem(menu_item);
    console.log('handleUserAsksForMenuItem + getMenuItem');
    console.log(response);

    if (response.status == 0) {
        return getErrorMessage();
    }

    if (response.status == 2) {
        return {
            fulfillmentText: `Sorry, we don't serve ${menu_item} at this moment. You can search for other food items.`
        }
    }

    if (response.status == 1 && !response.data[0].isActive) {
        return {
            fulfillmentText: `Sorry, we have stopped receiving new orders for ${menu_item}. Please try again afyer sometimes.`
        };
    }

    if (response.status == 1 && response.data[0].Modifier_Groups === 'Spice Level') {
        let session = req.body.session;
        let await_spicy_level = `${session}/contexts/await_spicy_level`;
        let session_cart = `${session}/contexts/session_cart`;
        return {
            fulfillmentText: `We have ${menu_item}, it costs ${response.data[0].Price}$. Please choose a spicy level for the ${menu_item} from Mild, Medium or Spicy.`,
            outputContexts: [
                {
                    name: await_spicy_level,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        item: response.data[0]
                    }
                }
            ]
        };
    }

    if (response.status == 1) {
        let session = req.body.session;
        let await_quantity = `${session}/contexts/await_quantity`;
        let session_cart = `${session}/contexts/session_cart`;
        return {
            fulfillmentText: `We have ${menu_item}, it costs ${response.data[0].Price}$. Please provide the quantity for the ${menu_item}.`,
            outputContexts: [
                {
                    name: await_quantity,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        item: response.data[0]
                    }
                }
            ]
        };
    }
};


const handleUserProvidesSpiceLevel = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let quantity = 0;
    let item;
    let spicy_level = 'None';
    let cart = [];


    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            quantity = outputContext.parameters.quantity;
            item = outputContext.parameters.item;
            if (outputContext.parameters.hasOwnProperty('spicy_level')) {
                spicy_level = outputContext.parameters.spicy_level;
            }
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    if (typeof quantity !== 'undefined' && quantity != 0) {

        let flag = true;

        cart.forEach(cart_item => {
            if (cart_item.item_name === item.Name) {
                cart_item.item_quantity = cart_item.item_quantity + quantity;
                flag = false;
            }
        });

        if (flag) {
            cart.push({
                item_name: item.Name,
                item_quantity: quantity,
                item_spicy_level: spicy_level,
                item_price: item.Price
            });
        }

        let session = req.body.session;
        let await_add_more_item = `${session}/contexts/await_add_more_item`;
        let session_cart = `${session}/contexts/session_cart`;

        return {
            fulfillmentText: `${item.Name} is added to the order. Do you want to add another item?`,
            outputContexts: [
                {
                    name: await_add_more_item,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        cart: cart
                    }
                }
            ]
        };
    }
    return {
        fulfillmentText: `Please provide the quantity for the item ${item.Name}`,
        outputContexts: [
            {
                name: await_quantity,
                lifespanCount: 1
            },
            {
                name: session_cart,
                lifespanCount: 50,
                parameters: {
                    cart: cart
                }
            }
        ]
    };
};



const handleUserProvidesQuantity = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let quantity, item;
    let spicy_level = 'None';
    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            quantity = outputContext.parameters.quantity;
            item = outputContext.parameters.item;
            if (outputContext.parameters.hasOwnProperty('spicy_level')) {
                spicy_level = outputContext.parameters.spicy_level;
            }
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let flag = true;

    cart.forEach(cart_item => {
        if (cart_item.item_name === item.Name) {
            cart_item.item_quantity = cart_item.item_quantity + quantity;
            flag = false;
        }
    });

    if (flag) {
        cart.push({
            item_name: item.Name,
            item_quantity: quantity,
            item_spicy_level: spicy_level,
            item_price: item.Price
        });
    }

    let session = req.body.session;
    let await_add_more_item = `${session}/contexts/await_add_more_item`;
    let session_cart = `${session}/contexts/session_cart`;

    return {
        fulfillmentText: `${item.Name} is added to the order. Do you want to add another item?`,
        outputContexts: [
            {
                name: await_add_more_item,
                lifespanCount: 1
            },
            {
                name: session_cart,
                lifespanCount: 50,
                parameters: {
                    cart: cart
                }
            }
        ]
    };
};

const handleUserDoesNotWantToAddMoreItem = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            cart = outputContext.parameters.cart;
        }
    });

    console.log(JSON.stringify(cart));

    let outString = 'Here is the order summary.\n';

    for (let index = 0; index < cart.length; index++) {
        const element = cart[index];

        if (index == cart.length - 1) {
            outString += `${element.item_name}, ${element.item_quantity} quantity.`;
        } else {
            outString += `${element.item_name}, ${element.item_quantity} quantity, `;
        }
    }

    outString += '\nDo you want to remove any item?';
    let session = req.body.session;
    let await_remove_from_cart = `${session}/contexts/await_remove_from_cart`;

    return {
        fulfillmentText: outString,
        outputContexts: [
            {
                name: await_remove_from_cart,
                lifespanCount: 1
            }
        ]
    };
};

const handleUserAgreesMenuItemToAddToCart = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let item;

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            item = outputContext.parameters.item;
        }
    });

    if (item.Modifier_Groups === 'Spice Level') {
        let session = req.body.session;
        let await_spicy_level = `${session}/contexts/await_spicy_level`;
        return {
            fulfillmentText: `Please choose a spicy level for the ${item.Name} from Mild, Medium or Spicy.`,
            outputContexts: [
                {
                    name: await_spicy_level,
                    lifespanCount: 1
                }
            ]
        };
    } else {
        let session = req.body.session;
        let await_quantity = `${session}/contexts/await_quantity`;
        return {
            fulfillmentText: `Please provide the quantity for the ${item.Name}.`,
            outputContexts: [
                {
                    name: await_quantity,
                    lifespanCount: 1
                }
            ]
        };
    }
};

const handleUserAsksForMenuItemWithQuantity = async (req) => {

    let menu_item = req.body.queryResult.parameters.menu_item;
    let quantity = req.body.queryResult.parameters.quantity;

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let response = await FIREBASE_API.getMenuItem(menu_item);
    console.log('handleUserAsksForMenuItemWithQuantity + getMenuItem');
    console.log(response);

    if (response.status == 0) {
        return getErrorMessage();
    }

    if (response.status == 2) {
        return {
            fulfillmentText: `Sorry, we don't serve ${menu_item} at this moment. You can search for items from our Menu avaiable in our website`
        }
    }

    let spicy_level = response.data[0].Modifier_Groups;

    if (spicy_level === '' || typeof spicy_level == 'undefined') {

        spicy_level = 'None';

        let flag = true;

        cart.forEach(cart_item => {
            if (cart_item.item_name === menu_item) {
                cart_item.item_quantity = cart_item.item_quantity + quantity;
                flag = false;
            }
        });

        if (flag) {
            cart.push({
                item_name: menu_item,
                item_quantity: quantity,
                item_spicy_level: spicy_level,
                item_price: response.data[0].Price
            });
        }
    }
    let session = req.body.session;
    let session_cart = `${session}/contexts/session_cart`;

    if (response.status == 1 && response.data[0].Modifier_Groups === 'Spice Level') {
        let await_spicy_level = `${session}/contexts/await_spicy_level`;
        return {
            fulfillmentText: `Please choose a spicy level for the ${menu_item} from Mild, Medium or Spicy.`,
            outputContexts: [
                {
                    name: await_spicy_level,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        item: response.data[0],
                        cart: cart
                    }
                }
            ]
        };
    }

    if (response.status == 1) {
        let await_add_more_item = `${session}/contexts/await_add_more_item`;
        return {
            fulfillmentText: `${menu_item} is aded to the order. Do you want to add another item?`,
            outputContexts: [
                {
                    name: await_add_more_item,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        item: response.data[0],
                        cart: cart
                    }
                }
            ]
        };
    }
};

const handleUserWantsToRemoveItem = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let outString = 'Please provide a menu item from the following list.\n';

    for (let index = 0; index < cart.length; index++) {
        const element = cart[index];

        if (index == cart.length - 1) {
            outString += `${element.item_name}.`;
        } else {
            outString += `${element.item_name}, `;
        }
    }

    let session = req.body.session;
    let await_remove_menu_item = `${session}/contexts/await_remove_menu_item`;

    return {
        fulfillmentText: outString,
        outputContexts: [
            {
                name: await_remove_menu_item,
                lifespanCount: 1
            }
        ]
    };
};

const handleUserProvidesRemoveMenuItem = async (req) => {

    let remove_menu_item = req.body.queryResult.parameters.menu_item;

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let new_cart = [];

    for (let index = 0; index < cart.length; index++) {
        const element = cart[index];
        if (element.item_name === remove_menu_item) {
        } else {
            new_cart.push(element);
        }
    }

    if (new_cart.length == 0) {
        return {
            fulfillmentText: 'Your order is empty, you can choose a menu item to get started.'
        };
    }

    if (new_cart.length != 0) {
        let outString = 'Here is the order summary.\n';

        for (let index = 0; index < new_cart.length; index++) {
            const element = new_cart[index];

            if (index == new_cart.length - 1) {
                outString += `${element.item_name}, ${element.item_quantity} quantity.`;
            } else {
                outString += `${element.item_name}, ${element.item_quantity} quantity, `;
            }
        }

        outString += '\nDo you want to remove any item?';
        let session = req.body.session;
        let await_remove_from_cart = `${session}/contexts/await_remove_from_cart`;
        let session_cart = `${session}/contexts/session_cart`;

        return {
            fulfillmentText: outString,
            outputContexts: [
                {
                    name: await_remove_from_cart,
                    lifespanCount: 1
                },
                {
                    name: session_cart,
                    lifespanCount: 50,
                    parameters: {
                        cart: new_cart
                    }
                }
            ]
        };
    }
};

const handleUserDoesNotWantToRemoveItem = async (req) => {

    let outputContexts = req.body.queryResult.outputContexts;

    let cart = [];

    outputContexts.forEach(outputContext => {
        let session = outputContext.name;
        if (session.includes('/contexts/session_cart')) {
            if (outputContext.parameters.hasOwnProperty('cart')) {
                cart = outputContext.parameters.cart;
            }
        }
    });

    let outString = 'Here is the order summary.\n';

    let total_amount = 0.0;

    for (let index = 0; index < cart.length; index++) {
        const element = cart[index];

        if (index == cart.length - 1) {
            outString += `${element.item_name}, ${element.item_quantity} quantity.`;
        } else {
            outString += `${element.item_name}, ${element.item_quantity} quantity, `;
        }

        total_amount += (Number(element.item_price) * Number(element.item_quantity));
    }

    outString += `\nTotal bill amount ${total_amount.toFixed(2)}$.`;

    outString += '\nPlease provide your name to complete the order.';

    let session = req.body.session;
    let await_name = `${session}/contexts/await_name`;

    return {
        fulfillmentText: outString,
        outputContexts: [
            {
                name: await_name,
                lifespanCount: 1
            }
        ]
    };
};

const BASE_URL = 'https://us-central1-hyderabadrasoi-kchq.cloudfunctions.net/webhook';
// const BASE_URL = 'https://fat-bulldog-92.loca.lt/hyderabadrasoi-kchq/us-central1/webhook'

const create_clovia_order = (cart, mobile, name) => {

    let data = JSON.stringify({
        'cart': cart,
        'mobile': mobile,
        'name': name
    });

    let config = {
        method: 'post',
        url: `${BASE_URL}/create_order`,
        headers: {
            'Content-Type': 'application/json'
        },
        data: data
    };

    axios(config);
};

const handleUserProvidesMobile = async (req) => {

    let responseData = await checkRestaurantTimings();

    if (responseData.status == 1) {
        return {
            fulfillmentText: responseData.fulfillmentText
        };
    } else {
        let outputContexts = req.body.queryResult.outputContexts;

        let cart = [], name, mobile;

        outputContexts.forEach(outputContext => {
            let session = outputContext.name;
            if (session.includes('/contexts/session_cart')) {
                if (outputContext.parameters.hasOwnProperty('cart')) {
                    cart = outputContext.parameters.cart;
                    name = outputContext.parameters.person.name;
                    mobile = outputContext.parameters.mobile;
                }
            }
        });

        let order = {
            cart: cart,
            name: name,
            phone: mobile,
            created_at: new Date()
        };

        let data = await FIREBASE_API.createOrder(order);

        if (data.status == 1) {
            // let html = ORDER_API.createOrderHTML(order);

            // // Use your mail address
            // MAIL_API.sendMail('Test message', 'ajay.sk@gmail.com', 'Order details', html);

            // let url = `${BASE_URL}/order_details/doc/${data.id}`;
            // let sms = `Hello, you have received a new order.\nYou can view the order here:\n${url}`;

            // // Use your number to receive SMS
            // TWILIO_API.sendSMS(`+14806857108`, sms);

            // // Create Clovia order and print it
            // create_clovia_order(cart, mobile, name);

            let session = req.body.session;
            let session_cart = `${session}/contexts/session_cart`;

            return {
                fulfillmentText: 'Your order is confirmed. Thank you. You can pay for your order here: https://www.payyourorder.com',
                outputContexts: [
                    {
                        name: session_cart,
                        lifespanCount: 0
                    }
                ]
            };
        } else {
            return getErrorMessage();
        }
    }
};

const handleUserProvidesName = async (req) => {

    let responseData = await checkRestaurantTimings();

    if (responseData.status == 1) {
        return {
            fulfillmentText: responseData.fulfillmentText
        };
    } else {
        let session = req.body.session;

        if (session.split('/')[4].includes('whatsapp')) {
            let outputContexts = req.body.queryResult.outputContexts;

            let cart = [], name, mobile;

            outputContexts.forEach(outputContext => {
                let session = outputContext.name;
                if (session.includes('/contexts/session_cart')) {
                    if (outputContext.parameters.hasOwnProperty('cart')) {
                        cart = outputContext.parameters.cart;
                        name = outputContext.parameters.person.name;
                    }
                }
            });

            mobile = session.split('/')[4].split(':')[1];

            let order = {
                cart: cart,
                name: name,
                phone: mobile,
                created_at: new Date()
            };

            let data = await FIREBASE_API.createOrder(order);

            if (data.status == 1) {
                // let html = ORDER_API.createOrderHTML(order);

                // // Use your mail address
                // MAIL_API.sendMail('Test message', 'ajay.sk@gmail.com', 'Order details', html);

                // let url = `${BASE_URL}/order_details/doc/${data.id}`;
                // let sms = `Hello, you have received a new order.\nYou can view the order here:\n${url}`;

                // // Use your number to receive SMS
                // TWILIO_API.sendSMS(`+14806857108`, sms);

                // // Create Clovia order and print it
                // create_clovia_order(cart, mobile, name);

                let session = req.body.session;
                let session_cart = `${session}/contexts/session_cart`;

                return {
                    fulfillmentText: 'Your order is confirmed. Thank you. You can pay for your order here: https://www.payyourorder.com',
                    outputContexts: [
                        {
                            name: session_cart,
                            lifespanCount: 0
                        }
                    ]
                };
            } else {
                return getErrorMessage();
            }
        } else {
            let session = req.body.session;
            let await_mobile = `${session}/contexts/await_mobile`;

            return {
                fulfillmentText: 'Please provide your mobile number to confirm the order.',
                outputContexts: [
                    {
                        name: await_mobile,
                        lifespanCount: 1
                    }
                ]
            };
        }
    }
};

const handleOrderFood = async (req) => {

    let response = await FIREBASE_API.getConfiguration();
    console.log('handleOrderFood + getConfiguration');
    console.log(response);

    if (response.status == 0) {
        return getErrorMessage();
    } else {
        if (response.data[0].isActive) {
            let session = req.body.session;
            let await_menu_item = `${session}/contexts/await_menu_item`;
            let session_cart = `${session}/contexts/session_cart`;

            return {
                fulfillmentText: `Please let me know the name of the item you want to order. You can mention one item at a time with quantity. For example, I want one chicken tikka masala.`,
                outputContexts: [
                    {
                        name: await_menu_item,
                        lifespanCount: 1
                    },
                    {
                        name: session_cart,
                        lifespanCount: 50
                    }
                ]
            };
        } else {
            return {
                fulfillmentText: `We are sorry, we have stopped accepting order for a timebeing, please try after sometimes.`
            };
        }
    }
};

const handleStopMenuItem = (req) => {

    let menu_item = req.body.queryResult.parameters.menu_item;
    FIREBASE_API.updateMenuItem(menu_item, false);

    return {
        fulfillmentText: `${menu_item} is now stopped. Don't forget to start it once you want to receive new orders.`
    };
};

const handleStartMenuItem = (req) => {

    let menu_item = req.body.queryResult.parameters.menu_item;
    FIREBASE_API.updateMenuItem(menu_item, true);

    return {
        fulfillmentText: `You can now receive new orders for ${menu_item}.`
    };
};

const handleStopRestaurant = async (req) => {

    let queryText = req.body.queryResult.queryText;

    let response = await FIREBASE_API.getConfiguration();

    let words = queryText.trim().split(' ');

    if (words.length != 3) {
        return {
            fulfillmentText: 'There are more than three words in the query.'
        };
    }

    if (response.status == 1) {
        if (words[1] !== response.data[0].username) {
            return {
                fulfillmentText: 'Wrong username, try again.'
            };
        } else if (words[2] !== response.data[0].password) {
            return {
                fulfillmentText: 'Wrong password, try again.'
            };
        } else {
            FIREBASE_API.updateConfiguration(false);
            return {
                fulfillmentText: 'SweetMagic will not receive new orders now.'
            };
        }
    } else {
        return getErrorMessage();
    }
};

const handleStartRestaurant = async (req) => {

    let queryText = req.body.queryResult.queryText;

    let response = await FIREBASE_API.getConfiguration();

    let words = queryText.trim().split(' ');

    if (words.length != 3) {
        return {
            fulfillmentText: 'There are more than three words in the query.'
        };
    }

    if (response.status == 1) {
        if (words[1] !== response.data[0].username) {
            return {
                fulfillmentText: 'Wrong username, try again.'
            };
        } else if (words[2] !== response.data[0].password) {
            return {
                fulfillmentText: 'Wrong password, try agai.'
            };
        } else {
            FIREBASE_API.updateConfiguration(true);
            return {
                fulfillmentText: 'SweetMagic will receive new orders now.'
            };
        }
    } else {
        return getErrorMessage();
    }
};

router.post('/dialogflow', async (req, res) => {

    let action = req.body.queryResult.action;

    console.log('Webhook called.');
    console.log(`Action name --> ${action}`);
    console.log(`Session id --> ${req.body.session}`);

    let responseData = {};


    if (action === 'handleUserAsksForMenuItem') {
        responseData = await handleUserAsksForMenuItem(req);
    } else if (action === 'checkTimingsForOrder') {
        responseData = await checkTimingsForOrder();
    } else if (action === 'handleUserProvidesMenuItem') {
        responseData = await handleUserProvidesMenuItem(req);
    } else if (action === 'handleUserProvidesQuantity') {
        responseData = await handleUserProvidesQuantity(req);
    } else if (action === 'handleUserDoesNotWantToAddMoreItem') {
        responseData = await handleUserDoesNotWantToAddMoreItem(req);
    } else if (action === 'handleUserAgreesMenuItemToAddToCart') {
        responseData = await handleUserAgreesMenuItemToAddToCart(req);
    } else if (action === 'handleUserAsksForMenuItemWithQuantity') {
        responseData = await handleUserAsksForMenuItemWithQuantity(req);
    } else if (action === 'handleUserWantsToRemoveItem') {
        responseData = await handleUserWantsToRemoveItem(req);
    } else if (action === 'handleUserProvidesRemoveMenuItem') {
        responseData = await handleUserProvidesRemoveMenuItem(req);
    } else if (action === 'handleUserDoesNotWantToRemoveItem') {
        responseData = await handleUserDoesNotWantToRemoveItem(req);
    } else if (action === 'handleUserProvidesName') {
        responseData = await handleUserProvidesName(req);
    } else if (action === 'handleUserProvidesMobile') {
        responseData = await handleUserProvidesMobile(req);
    } else if (action === 'handleUserProvidesSpiceLevel') {
        responseData = await handleUserProvidesSpiceLevel(req);
    } else if (action === 'handleOrderFood') {
        responseData = await handleOrderFood(req);
    } else if (action === 'handleStopMenuItem') {
        responseData = handleStopMenuItem(req);
    } else if (action === 'handleStartMenuItem') {
        responseData = handleStartMenuItem(req);
    } else if (action === 'handleStopRestaurant') {
        responseData = await handleStopRestaurant(req);
    } else if (action === 'handleStartRestaurant') {
        responseData = await handleStartRestaurant(req);
    } else {
        responseData['fulfillmentText'] = `No handler for the action --> ${action}`;
    }

    console.log('Response sent from webhook.');
    console.log(responseData);

    res.send(responseData);
});

module.exports = {
    router
};