const express = require('express');
const router = express.Router();

const ORDER_API = require('../helper_functions/order_api');
const FIREBASE_API = require('../helper_functions/firebase_api');

router.get('/order_details/doc/:doc_id', async (req, res) => {

    let doc_id = req.params.doc_id;

    let data = await FIREBASE_API.getOrderDetails(doc_id);
    let order = data.doc;

    console.log(data.doc);

    let html = ORDER_API.createOrderHTML(order);

    res.send(html);
});

module.exports = {
    router
};