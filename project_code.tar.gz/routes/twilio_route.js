const express = require('express');
const router = express.Router();

const TWILIO_API = require('../helper_functions/twilio_api');
const DIALOGFLOW_API = require('../helper_functions/dialogflow_api');

router.post('/twilio', async (req, res) => {

    let message = req.body.Body;
    let sender_id = req.body.From;

    let intent_data = await DIALOGFLOW_API.detectIntent('en', message, sender_id);
    let text = intent_data.text;

    if (text === '') {
        text = 'We are facing a problem at our end, please try after sometime.'
    }

    TWILIO_API.sendWhatsAppMessage(text, sender_id);

    // res.sendStatus(text);
});

module.exports = {
    router
};